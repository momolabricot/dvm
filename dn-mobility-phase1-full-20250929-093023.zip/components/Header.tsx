export default function Header(){
  return (
    <header className="bg-white/70 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <a href="/" className="font-semibold text-lg">DN Mobility</a>
        <nav className="flex gap-5 text-sm">
          <a href="/a-propos">À propos</a>
          <a href="/simulateur">Simulateur</a>
          <a href="/contact">Contact</a>
        </nav>
      </div>
    </header>
  )
}
